import { Address } from "./Address";

export interface Customer{
    "customerId":number;
    "firstName":string;
    "lastName":string;
    "mobileNumber":string;
    "emailId":string;
    "addresses":Address[];
    "isVerified":boolean
}