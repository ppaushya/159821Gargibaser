import { Component, OnInit } from '@angular/core';
import { CustomerService } from './customers.service';
import { Customer } from './customer';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {

  constructor(private customerService: CustomerService) { }

  customers: Customer[]=[];

  ngOnInit() {
    this.getCustomers();
  }

  getCustomers(): void{
    this.customerService.getCustomers()
    .subscribe(customers => {this.customers = customers;console.log(customers)
    });
  }

}
