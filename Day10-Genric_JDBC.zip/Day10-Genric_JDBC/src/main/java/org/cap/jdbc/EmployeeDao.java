package org.cap.jdbc;

import java.time.LocalDate;
import java.util.List;

public interface EmployeeDao {
	
	public void createEmployee(Employee employee);
	public void deleteEmployee(int employeeId);
	
	public List<Employee>  getAllEmployees();
	
	public Employee callProcedure(int employeeId);
	public void callBulkInsertion();
	void updateLastName(String lName, int empId);
	void updateDoj(LocalDate doj, int empId);
	void updateSalary(int sal, int empId);
	
	public void updateFirstName(String fName, int empId);
	public List<Employee> findEmployee(int empId);
	public List<Employee> findEmployee1(int empId);

}
