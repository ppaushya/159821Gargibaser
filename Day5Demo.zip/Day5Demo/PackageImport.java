package Assignments;
import Balance.*;

public class PackageImport {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account acc=new Account();
		acc.display_Balance(100);
	}

}