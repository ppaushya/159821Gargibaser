package Assignments;

public class Balance {
	private int balance;
    public void getBalance(int b)
    {
        balance=b;
    }
    public void Display_Balance()
    {
        System.out.println("Balance is "+balance);
    }}