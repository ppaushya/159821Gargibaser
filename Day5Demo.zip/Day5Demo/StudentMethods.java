package Assignments;

public interface StudentMethods {
	
	public void displayGrade();
	public void displayAttendence();
}