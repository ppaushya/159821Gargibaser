package Assignments;

public class MainClass {
	 public static void main(String[] args)
	    {
	    Balance obj=new Balance();
	    obj.getBalance(7500);
	    obj.Display_Balance();
	    }
}
