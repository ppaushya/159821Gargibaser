package util;

public class Utility {

	public static int generateNumber() {
		// TODO Auto-generated method stub
return(int) (Math.random()*1000)/100;
		
		
	}

}
