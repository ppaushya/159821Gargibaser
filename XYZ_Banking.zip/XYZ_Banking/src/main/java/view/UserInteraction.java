package view;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import model.Customer;
import util.Utility;

public class UserInteraction {
	Scanner scanner=new Scanner(System.in);
	
	public void printCustomers(List<Customer> customers) {
		System.out.println("CustomerId\tCustomerName\tEmailId\tMobile");
		System.out.println("-----------------------------------------------------------------------------");
		
		for(Customer customer:customers) {
			System.out.println(customer.getCustomerId()
					+"\t\t"+customer.getFirstName()+" " + customer.getLastname()
					+"\t"+ customer.getEmailid() + "\t" + customer.getMobileno() );
		}
	}
	
	public Customer getCustomerdetails() {
		Customer customer=new Customer();
		customer.setCustomerId(Utility.generateNumber());
		customer.setFirstName(promptFirstName());
		customer.setLastname(promptLastName());
		customer.setEmailid(promptEmailId());
		customer.setMobileno(promptMobileNo());
		customer.setDateofBirth(promptDateofBirth());
		
		return customer;
	}
		public String promptFirstName()
		{
			boolean flag=false;
			String fname;
			do {
				System.out.println("enter first name");
				fname=scanner.next();
				flag =fname.matches("[A-Za-z]{3,}");
				if(!flag)
					System.out.println("enter valid first name");	
				
			}while(!flag);
			return fname;
		}
		
		
		
		public String promptLastName()
		{
			boolean flag=false;
			String lname;
			do {
				System.out.println("enter last name");
				lname=scanner.next();
				flag =lname.matches("[A-Za-z]{3,}");
				if(!flag)
					System.out.println("enter valid last name");	
				
			}while(!flag);
			return lname;
		}
		public String promptEmailId()
		{
			boolean flag=false;
			String email;
			do {
				System.out.println("enter email id");
				email=scanner.next();
				flag =email.matches("[a-z0-9.]+@gmail.com");
				if(!flag)
					System.out.println("enter valid emailid");	
				
			}while(!flag);
			return email;
		}
		public String promptMobileNo()
		{
			boolean flag=false;
			String mobileNo;
			do {
				System.out.println("enter mobile number");
				mobileNo=scanner.next();
				flag =mobileNo.matches("\\d{10}");
				if(!flag)
					System.out.println("enter valid mobile number");	
				
			}while(!flag);
			return mobileNo;
		}
		public LocalDate promptDateofBirth()
		{
			String dob;
		LocalDate date; 
				boolean flag=false;
						do	{
					
							System.out.println("Enter date of birth in format DD/MM/YYYY:");
							dob=scanner.next();
								flag=dob.matches("[0-9]{2}/[0-9]{2}/[0-9]{4}");
							if(flag==false)
							{
								System.out.println("Enter valid date!");
							}
						}while(flag==false);
						
						
						
						date=LocalDate.parse(dob, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
						return date; 

	}
		public void printError(String message) {
			System.out.println(message);
			
		}
			
		
	}

