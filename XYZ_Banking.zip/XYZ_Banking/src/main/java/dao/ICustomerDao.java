package dao;

import java.util.List;

import model.Customer;

public interface ICustomerDao {
	public List<Customer> getAllCustomers();
	public void createCustomer(Customer customer);

}
