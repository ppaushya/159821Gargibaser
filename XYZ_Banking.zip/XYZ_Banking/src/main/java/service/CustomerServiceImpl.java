package service;


	import java.time.LocalDate;
	import java.util.List;

	import dao.CustomerDaoImpl;
	import dao.ICustomerDao;
	import model.Customer;

	public class CustomerServiceImpl implements ICustomerService{
		
		private ICustomerDao customerDao=new CustomerDaoImpl();
		
		

		@Override
		public void createCustomer(Customer customer) {
			if(isValidCustomer(customer)) {
						customerDao.createCustomer(customer);
			}
			
			
		}
		
		private boolean isValidCustomer(Customer customer) {
			boolean flag=false;
			
			if(customer.getDateofBirth().isBefore(LocalDate.now())) {
				if(customer.getMobileno().matches("(7|8|9)\\d{9}"))
					flag=true;
				else
					flag=false;
			}else
				flag=false;
			
			
			return flag;
		}

		@Override
		public List<Customer> getAllCustomers() {
			
			return customerDao.getAllCustomers();
		}

}
