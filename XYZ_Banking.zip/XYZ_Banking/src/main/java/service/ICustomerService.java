package service;

import java.util.List;

import model.Customer;

public interface ICustomerService {
	public void createCustomer(Customer customer);
	public List<Customer> getAllCustomers();
}
