package model;

import java.time.LocalDate;
import java.util.Date;
import java.util.Set;

public class Customer {
private int customerId;
private String firstName;
private String lastname;
private String emailid;
private String mobileno;
private LocalDate dateofBirth;
private Address address;
private Set<Account> accounts;

public Customer() {
	super();
}
public Customer(Set<Account> accounts) {
	super();
	this.accounts = accounts;
}
@Override
public String toString() {
	return "Customer [customerId=" + customerId + ", firstName=" + firstName + ", lastname=" + lastname + ", emailid="
			+ emailid + ", mobileno=" + mobileno + ", dateofBirth=" + dateofBirth + ", address=" + address
			+ ", accounts=" + accounts + "]";
}
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
public String getEmailid() {
	return emailid;
}
public void setEmailid(String emailid) {
	this.emailid = emailid;
}
public String getMobileno() {
	return mobileno;
}
public void setMobileno(String mobileno) {
	this.mobileno = mobileno;
}
public LocalDate getDateofBirth() {
	return dateofBirth;
}
public void setDateofBirth(LocalDate dateofBirth) {
	this.dateofBirth = dateofBirth;
}
public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}
public Set<Account> getAccounts() {
	return accounts;
}
public void setAccounts(Set<Account> accounts) {
	this.accounts = accounts;
}
public void setPincode(String promptPincode) {
	// TODO Auto-generated method stub
	
}

}
