package model;

import java.time.LocalDate;

public class Account {
private long accountNumber;
private AccountType accounttype;

@Override
public String toString() {
	return "Account [accountNumber=" + accountNumber + ", accounttype=" + accounttype + ", openingDate=" + openingDate
			+ ", openingBalance=" + openingBalance + ", description=" + description + "]";
}
public long getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(long accountNumber) {
	this.accountNumber = accountNumber;
}
public AccountType getAccounttype() {
	return accounttype;
}
public void setAccounttype(AccountType accounttype) {
	this.accounttype = accounttype;
}
public LocalDate getOpeningDate() {
	return openingDate;
}
public void setOpeningDate(LocalDate openingDate) {
	this.openingDate = openingDate;
}
public double getOpeningBalance() {
	return openingBalance;
}
public void setOpeningBalance(double openingBalance) {
	this.openingBalance = openingBalance;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
private LocalDate openingDate;
private double openingBalance;
private String description;
	
	
}
