package model;

public class AccountType {

}
