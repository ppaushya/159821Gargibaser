package Boot;

import model.Customer;
import model.UserInteraction;

public class BootClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
UserInteraction ui=new UserInteraction();
Customer c=new Customer();
c=ui.getCustomerdetails();
//System.out.println(c);
	}

}
