public class Main {
	

	public static void main(String[] args) {
		
		Customer cust= new Customer();
		
		
		
		for(int i=0;i<5;i++)
		{
			
			Account[] account=new Account[i];
			
		}

	}

}