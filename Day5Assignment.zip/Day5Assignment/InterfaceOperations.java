package Assignments;

public InterfaceOperations {
	
	public float division(float number1,float number2);
	public int modulo(int divident,int divisor);
}