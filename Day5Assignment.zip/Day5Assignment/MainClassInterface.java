package Assignments;

public class MainClassInterface {

	public static void main(String[] args)
	{
		RectangleArea rect=new RectangleArea();
		CircleArea cr=new CircleArea();

		System.out.println("rectangle area= "+rect.calcArea(10,20));
		System.out.println(" circle area= "+cr.calcArea(10,0));
	}
	
}