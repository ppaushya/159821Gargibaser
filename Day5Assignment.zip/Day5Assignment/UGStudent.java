package Assignments;

public class UGStudent extends Student implements StudentMethods{

	public UGStudent() {
		super();
	}
	
	public UGStudent(int studentId, String studentName, int attendence, char grade) {
		super(studentId,studentName,attendence,grade);
	}

	@Override
	public void displayGrade() {
		System.out.println(" UG Student's grade: "+grade);
	}

	@Override
	public void displayAttendence() {
		System.out.println(" UG Student's attendance: "+attendence);
	}
	
}
