package Assignments;

public class MainClassStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		UGStudent ug = new UGStudent(12,"Gargi",96,'A');
		ug.displayAttendence();
		ug.displayGrade();


		PGStudent pg = new PGStudent(22,"Prashul",78,'C');
		pg.displayAttendence();
		pg.displayGrade();
		
	}

}