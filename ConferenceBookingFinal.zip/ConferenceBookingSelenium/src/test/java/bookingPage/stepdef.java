package bookingPage;



import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {
	
	private WebDriver webdriver;
	private WebElement webelement, element;
	private String message;

	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\gbaser\\Downloads\\selenium\\chromedriver.exe");
	webdriver = new ChromeDriver();
	}

	@Given("^Open ConferenceRegistartion\\.html page$")
	public void open_ConferenceRegistartion_html_page() throws Throwable {
	webdriver.get("file:///C:/Users/gbaser/Downloads/Conferencebooking/ConferenceRegistartion.html"); 
	
	}

	@Given("^provide correct details$")
	public void provide_correct_details() throws Throwable {
	// 3. page name
	if (!webdriver.getTitle().startsWith("Conference Registartion")) {
	webdriver.quit();
	}

	// 4. heading
	webelement = webdriver.findElement(By.xpath("/html/body/h4"));
	if (!webelement.getText().equals("Step 1: Personal Details")) {
	webdriver.quit();
	}

	// 5. first name
	element = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
	element.click();
	message = webdriver.switchTo().alert().getText();
	assertEquals(message, "Please fill the First Name");
	webdriver.switchTo().alert().accept();
	webdriver.findElement(By.xpath("//*[@id=\"txtFirstName\"]")).sendKeys("Amit");

	// 6. last name
	element = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
	element.click();
	message = webdriver.switchTo().alert().getText();
	assertEquals(message, "Please fill the Last Name");
	webdriver.switchTo().alert().accept();
	webdriver.findElement(By.xpath("//*[@id=\"txtLastName\"]")).sendKeys("Kumar");

	// 7. email
	element = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
	element.click();
	message = webdriver.switchTo().alert().getText();
	assertEquals(message, "Please fill the Email");
	webdriver.switchTo().alert().accept();
	webdriver.findElement(By.xpath("//*[@id=\"txtEmail\"]")).sendKeys("amit@gmail.com");

	// 8. contact no
	element = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
	element.click();
	message = webdriver.switchTo().alert().getText();
	assertEquals(message, "Please fill the Contact No.");
	webdriver.switchTo().alert().accept();
	webdriver.findElement(By.xpath("//*[@id=\"txtPhone\"]")).sendKeys("5895689563");

	// 9. correct phone number
	element = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
	element.click();
	message = webdriver.switchTo().alert().getText();
	assertEquals(message, "Please enter valid Contact no.");
	webdriver.switchTo().alert().accept();
	webdriver.findElement(By.xpath("//*[@id=\"txtPhone\"]")).clear();
	webdriver.findElement(By.xpath("//*[@id=\"txtPhone\"]")).sendKeys("8895689563");

	// 10. number of people
	element = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
	element.click();
	message = webdriver.switchTo().alert().getText();
	assertEquals(message, "Please fill the Number of people attending");
	webdriver.switchTo().alert().accept();
	webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[5]/td[2]/select/option[2]")).click();

	// 11. street address
	webdriver.findElement(By.xpath("//*[@id=\"txtAddress1\"]")).sendKeys("MGR");
	webdriver.findElement(By.xpath("//*[@id=\"txtAddress2\"]")).sendKeys("MGR road");

	// 12. city
	webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[9]/td[2]/select/option[4]")).click();

	// 13. state
	webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[10]/td[2]/select/option[4]")).click();

	// 14. Conference full-Access(member)
	webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[12]/td[2]/input")).click();

	// 15. Conference full-Access(non-member)
	webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[13]/td[2]/input")).click();

	}

	@When("^click next link$")
	public void click_next_link() throws Throwable {
	// 16. next
	element = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
	element.click();

	message = webdriver.switchTo().alert().getText();
	assertEquals(message, "Personal details are validated.");
	webdriver.switchTo().alert().accept();
	}

	@Then("^navigate to PaymentDetails\\.html$")
	public void navigate_to_PaymentDetails_html() throws Throwable {
	// 16. next
	message = webdriver.getCurrentUrl();
	assertEquals(message, "C:\\Users\\gbaser\\Downloads\\Conferencebooking\\PaymentDetails.html");

	webdriver.quit();
	}

	@Given("^Open PaymentDetails\\.html page$")
	public void open_PaymentDetails_html_page() throws Throwable {
	// 16. next
	webdriver.get("file:///D:/Users/sebhatt/Desktop/Conferencebooking/Conferencebooking/PaymentDetails.html");
	//message = webdriver.getCurrentUrl();
	//assertEquals(message, "file:///D:/Users/ketchauh/Downloads/Conferencebooking/PaymentDetails.html");
	}

	@Given("^correct details provided$")
	public void correct_details_provided() throws Throwable {
	// 17. first name
	// 18. last name
	webdriver.findElement(By.xpath("//*[@id=\"txtCardholderName\"]")).sendKeys("Amit Kumar");

	// 19. card number
	webdriver.findElement(By.xpath("//*[@id=\"txtDebit\"]")).sendKeys("7895632589657412");

	// 20. cvv
	webdriver.findElement(By.xpath("//*[@id=\"txtCvv\"]")).sendKeys("789");

	// 21. Expiration Month
	webdriver.findElement(By.xpath("//*[@id=\"txtMonth\"]")).sendKeys("05");

	// 22. Expiration Year
	webdriver.findElement(By.xpath("//*[@id=\"txtYear\"]")).sendKeys("2025");

	}

	@When("^click on Make Payment button$")
	public void click_on_Make_Payment_button() throws Throwable {
	// 23. register
	element = webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));
	element.click();
	}

	@Then("^show successful message$")
	public void show_successful_message() throws Throwable {
	// 23. register
	message = webdriver.switchTo().alert().getText();
	assertEquals(message, "Conference Room Booking successfully done!!!");
	webdriver.switchTo().alert().accept();

	webdriver.quit();
	}

}
