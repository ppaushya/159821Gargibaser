package org.cap.service;

import java.util.Set;

import org.cap.dao.AccountDaoImpl;
import org.cap.dao.IAccountDao;
import org.cap.model.Account;
import org.cap.model.Customer;

public class AccountServiceImpl implements IAccountService{
	private IAccountDao accountDao= new AccountDaoImpl();

	public void createAccount(Account account, int customerId) {
	
		accountDao.createAccount(account, customerId);
		
	}

	public Set<Account> getAccountsForCustomer(Customer customer) {
	
		return accountDao.getAccountsOfCustomer(customer);
	}
	
}
