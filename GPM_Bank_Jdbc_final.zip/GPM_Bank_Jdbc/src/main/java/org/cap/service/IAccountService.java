package org.cap.service;

import java.util.Set;

import org.cap.model.Account;
import org.cap.model.Customer;

public interface IAccountService {
public void createAccount(Account account, int customerIde);
	
	public Set<Account> getAccountsForCustomer(Customer customer);
	
}
