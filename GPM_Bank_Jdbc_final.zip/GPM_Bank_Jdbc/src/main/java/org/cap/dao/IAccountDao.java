package org.cap.dao;

import java.util.Set;

import org.cap.model.Account;
import org.cap.model.Customer;

public interface IAccountDao {
	public Set<Account> getAccountsOfCustomer(Customer customer);
	public void createAccount(Account account, int customerId);
	
}
