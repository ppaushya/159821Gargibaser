

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;



public class BootClass {
	
	
	
	static Scanner scanner=new Scanner(System.in);
	
	public static ArrayList<Customer> loadCustomer() {
		ArrayList<Customer> customers=new ArrayList<>();
		
		Address address=new Address("North Avennue", "Cross St", "Chennai", "TN");
		customers.add(new Customer(1001, "Tommmy",address ,new ArrayList<Account>(),  "12453535", "tommmy@gmail.com"));
		Account account=new Account(1234, AccountType.SAVINGS, LocalDate.now(), 45000);
		
		
		
		Address address1=new Address("South Avennue", "Cross St", "Hyderabad", "AP");
		customers.add(new Customer(1002, "Jerry",address1 ,new ArrayList<Account>(),   "43454354", "jerry@gmail.com"));
		
		Address address2=new Address("West car st", "Cross St", "Chennai", "TN");
		customers.add(new Customer(21321, "Jack",address2 , new ArrayList<Account>(),  "435435543", "jack@gmail.com"));
		
		Address address4=new Address("West Avennue", "Cross St", "Pune", "MH");
		customers.add(new Customer(87868, "Kamal",address4 ,new ArrayList<Account>(),   "43543543", "kamal@gmail.com"));
		
		Address address3=new Address("East Avennue", "Cross St", "Delhi", "UP");
		customers.add(new Customer(657657, "Jasmine",address3 , new ArrayList<Account>(), "352325", "jas@gmail.com"));
		
		
		return customers;
	}
	
	
	public static void printCustomer() {
		System.out.println("Available Customers:");
		ArrayList<Customer> customers=loadCustomer();
		for(Customer customer:customers) {
			System.out.println(customer.getCustomerId()+"\t"+customer.getCustomerName() +"\t"
					+customer.getEmailId()+"\t"+ customer.getMobile());
		}
		
	}
	
	
	
	public static void printAccountType() {
		AccountType[] types=AccountType.values();
		int count=0;
		for(AccountType type:types)
			System.out.println(++count + "." + type);
	}

	
	public static AccountType assignAccountType(int value) {
		switch(value) {
		case 1:
			return AccountType.SAVINGS;
		case 2:
			return AccountType.CURRENT;
		case 3:
			return AccountType.RD;
		case 4:
			return AccountType.FD;
		default:
			System.out.println("Invalid Account Type");
			System.exit(0);
		}
		
		return null;
	}
	
	
	public static Customer findCustomer(int customerId) {
		for(Customer customer:loadCustomer()) {
			if(customer.getCustomerId()==customerId)
				return customer;
		}
		return null;
	}
	
	
	public static void main(String[] args) {
		ArrayList<Transaction> transactions=new ArrayList<>();
		int choice;
		int customerId;
		int accountTypeNo;
		printCustomer();
		
		Validation valid=new Validation();
		char myChoice;
		int newCustomer;
		
		Customer newcustomer=new Customer();
		
		System.out.println("Do you want to add customer? type 1 for yes, 2 for no");
		newCustomer=scanner.nextInt();
		
		if(newCustomer==1)
		{
			String customerID;
			String customerName;
			String email;
			String mobile;
			
			System.out.println("Enter the customerID");
			customerID=scanner.next();
			if(valid.validateID(customerID)==0)
				return;
			
			System.out.println("Enter the customer name");
			customerName=scanner.next();
			if(valid.validateName(customerName)==0)
				return;
			
			System.out.println("Enter the customer email");
			email=scanner.next();
			if(valid.validateEmail(email)==0)
				return;
			
			System.out.println("Enter the mobile number");
			mobile=scanner.next();
			if(valid.validateMobile(mobile)==0)
				return;
			
			newcustomer=new Customer(Integer.parseInt(customerID), customerName,null , new ArrayList<Account>(), mobile, email);
			System.out.println("New customer added!");
			
		}
		
		System.out.println("Choose customer Id:");
		customerId=scanner.nextInt();
		Customer customer=findCustomer(customerId);
		
	do {
			if(customer!=null) {
				System.out.println("1.Create new Account");
				System.out.println("2.Perform Transaction");
				System.out.println("3.Transaction Summary");
				System.out.println("Enter your Choice[1,2]?");
				choice=scanner.nextInt();
				if(choice==1) {
					Account account=new Account();
					System.out.println("Enter Account details");
					account.setAccountNo(AccountTransaction.generateAccountNo());
					
					System.out.println("Choose Account Type[1,2,3,4]:");
						printAccountType();
						accountTypeNo=scanner.nextInt();
						account.setAccountType(assignAccountType(accountTypeNo));
					
					System.out.println("Enter account OpeningDate:");
					System.out.println("Enter year:");
					int year=scanner.nextInt();
					System.out.println("Enter Month:");
					int month=scanner.nextInt();
					System.out.println("Enter dayOfMonth:");
					int dayOfMonth=scanner.nextInt();
					
						LocalDate date=LocalDate.of(year, month, dayOfMonth);
						account.setOpeningDate(date);
						
					System.out.println("Enter Opening Balance:");
					account.setOpeningBalance(scanner.nextDouble());
					
					ArrayList<Account> account2=customer.getAccount();
					//System.out.println(account);
					for(int i=0;i<account2.size();i++)
					{
						if(account2.get(i)==null) {
							account2.set(i,account);
							break;
						}
					}
					System.out.println(customer);
					
				}else if(choice==2) {
					int index=0;
					AccountTransaction tx=new AccountTransaction();
					Transaction transaction;
			
					System.out.println("Choose Any one of the account number:");
					if(customer.getAccount().get(0)!=null)
						tx.printAccounts(customer);
					else
						System.out.println("Sorry! No account details present for this Customer.");
					long accountNo=scanner.nextLong();
					
					if(tx.isValidAccount(accountNo, customer)) {
						transaction=new Transaction();
						
						transaction.setTransactionId((int)AccountTransaction.generateAccountNo());
						
						System.out.println("1.Deposit");
						System.out.println("2.Withdrawal");
						System.out.println("Choose your option:");
						int option=scanner.nextInt();
						if(option==1)
							transaction.setTransactionType("credit");
						else if(option==2)
							transaction.setTransactionType("debit");
						else {
							System.out.println("Sorry! invalid option!");
							System.exit(0);
						}
						
						Account account=tx.findAccount(accountNo, customer);
						transaction.setAccount(account);
						transaction.setTransactionDate(LocalDate.now());
						
						System.out.println("Enter amount to deposit:");
						transaction.setAmount(scanner.nextDouble());
						transactions.set(index, transaction);
						index++;
					}
					
					
				}else if(choice==3) {
					
					printTransactionSummary(transactions);
					
				}else {
					System.out.println("Sorry! INvalid choice. Please try Again!");
				}
				
			}
			else {
				System.out.println("Invalid Customer Number! Please try.");
			}
			
			System.out.println("Would you like to continue[y|n]?");
			myChoice=scanner.next().charAt(0);
		}while(myChoice=='y'||myChoice=='Y');
	}
	
	
	
	
	
	
	
	public static void printTransactionSummary(ArrayList<Transaction> transactions) {
		System.out.println("\nTransaction Summary\n--------------------\n");
		
		for(Transaction transaction:transactions) {
			if(transaction!=null) {
			System.out.println(transaction.getTransactionDate() +"\t"
					+ transaction.getTransactionId()+"\t"
					+ transaction.getAccount().getAccountNo()+"\t"
					+transaction.getTransactionType()+"\t"
					+transaction.getAmount()
					);
			}
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
