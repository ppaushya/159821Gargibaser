package org.gaming.boot;

import java.util.Scanner;

import org.gaming.Dao.ICustomerDao;
import org.gaming.exceptions.InvalidCustomerException;
import org.gaming.model.Registration;
import org.gaming.services.CustomerServicesImpl;
import org.gaming.services.ICustomerServices;
import org.gaming.view.UserInteraction;

public class BootClass {

	public static void main(String[] args) throws InvalidCustomerException
	{
		Scanner scanner= new Scanner(System.in);
		
		UserInteraction userInteraction = new UserInteraction();
		
		ICustomerServices customerServices = new CustomerServicesImpl();

		boolean flag=true;
		
		do
		{
		Registration newReg=userInteraction.getregistrationdetails();
		
		System.out.println(newReg);
		
		customerServices.doCustomerRegistration(newReg);
	
		System.out.println("enter 1 to contiue and 2 to exit");
		
		int ch=scanner.nextInt();
	    
		if(ch==2)
		{
			flag=false;
		}
		
		}while(flag);
	}
	
}
