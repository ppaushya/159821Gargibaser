package org.cap.dao;

import java.util.HashSet;
import java.util.Set;

import org.cap.model.Account;
import org.cap.model.Customer;

public class AccountDaoImpl implements IAccountDao {

	Set<Account> accounts = dummyAccounts();
	private static Set<Account> dummyAccounts()	{
		
		Set<Account> accounts=new HashSet<>();
		
		return accounts;
	}
	
	@Override
	public Set<Account> getAccountsOfCustomer(Customer customer)
	{
		return accounts;
	}
	
	@Override
	public void createAccount(Account account)
	{
		accounts.add(account);
	}
	
	
}
