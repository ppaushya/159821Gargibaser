package org.cap.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.cap.model.Account;
import org.cap.model.Transaction;

public interface ITransactionDao {

	public List<Transaction> getAllTransactions(Account account);
	public void createTransaction(Account account, Transaction transaction);
}
