package org.cap.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.cap.model.Account;
import org.cap.model.Transaction;

public class TransactionDaoImpl implements ITransactionDao{
	List lst;
	   Map<Account, List<Transaction>> transactions = dummyTransactions();
	private static Map<Account, List<Transaction>> dummyTransactions()	{
		
		Map<Account, List<Transaction>> transactions=new HashMap<Account, List<Transaction>>();
		
		return transactions;
	}
	@Override
	public List<Transaction> getAllTransactions(Account account) {
		// TODO Auto-generated method stub
		return transactions.get(account);
	}
	@Override
	public void createTransaction(Account account, Transaction transaction) {
		// TODO Auto-generated method stub
				lst=new ArrayList<>();
				if(transactions.containsKey(account))
             {lst=transactions.get(account);
             lst.add(transaction);}
				else
				{
					lst.add(transaction);
					transactions.put(account, lst);}
		transactions.put(account,lst);
	}
	
	
}
