package org.cap.service;

import java.util.List;

import org.cap.dao.CustomerDaoImpl;
import org.cap.dao.ICustomerDao;
import org.cap.model.Customer;

public class CustomerServiceImpl implements ICustomerService{
private ICustomerDao customerdao= new CustomerDaoImpl();
	
	
	
	
	@Override
	public void createCustomer(Customer customer) {
		// TODO Auto-generated method stub
	
		if(isValidCustomer(customer)) 
		{
		customerdao.createCustomer(customer);
	}
	}


	private boolean isValidCustomer(Customer customer) {
		boolean flag=false;
		
		
			if(customer.getMobile().matches("(7|8|9)\\d{9}"))
				flag=true;
			else
				flag=false;
		
		return flag;
	}
	
	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return customerdao.getAllCustomers();
	}

	
}
