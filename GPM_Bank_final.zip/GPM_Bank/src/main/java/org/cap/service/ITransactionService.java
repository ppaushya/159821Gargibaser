package org.cap.service;

import java.util.List;

import org.cap.model.Account;
import org.cap.model.Transaction;

public interface ITransactionService {
public void createTransaction(Account account,Transaction transaction);
	
	public List<Transaction> getAllTransactions(Account account);
	
}
