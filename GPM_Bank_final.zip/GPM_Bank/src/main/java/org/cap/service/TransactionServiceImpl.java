package org.cap.service;

import java.util.List;

import org.cap.dao.ITransactionDao;
import org.cap.dao.TransactionDaoImpl;
import org.cap.model.Account;
import org.cap.model.Transaction;

public class TransactionServiceImpl implements ITransactionService{

private ITransactionDao transDao=new TransactionDaoImpl();
	
	@Override
	public void createTransaction(Account account,Transaction transaction) {
		// TODO Auto-generated method stub
		transDao.createTransaction(account,transaction);
	}

	@Override
	public List<Transaction> getAllTransactions(Account account) {
		// TODO Auto-generated method stub
		return transDao.getAllTransactions(account);
	}
}
